import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Responsabilidad única: mostrar la pantalla de inicio y recoger
 * la configuración (filas, columnas) que el jugador elige antes
 * de empezar la partida.
 */
public class VistaPantallaTitulo {

    private final Stage stage;
    private int filas    = 4;
    private int columnas = 10;

    /** Callback invocado cuando el jugador pulsa «Jugar». */
    private Runnable alIniciar;

    public VistaPantallaTitulo(Stage stage) {
        this.stage = stage;
    }

    public void setAlIniciar(Runnable callback) {
        this.alIniciar = callback;
    }

    /** Construye y muestra la pantalla de bienvenida. */
    public void mostrar() {
        javafx.scene.layout.VBox root = new javafx.scene.layout.VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(20));

        Label titulo = new Label("Number Match");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 22));

        Spinner<Integer> spFilas = new Spinner<>(4, 14, filas);
        Spinner<Integer> spCols  = new Spinner<>(10, 22, columnas);

        spFilas.valueProperty().addListener((obs, ant, nuevo) -> filas    = nuevo);
        spCols .valueProperty().addListener((obs, ant, nuevo) -> columnas = nuevo);

        Button btnJugar = new Button("Jugar");
        btnJugar.setPrefWidth(120);
        btnJugar.setOnAction(e -> {
            if (alIniciar != null) alIniciar.run();
        });

        root.getChildren().addAll(
                titulo,
                new Label("Filas"),    spFilas,
                new Label("Columnas"), spCols,
                btnJugar
        );

        stage.setScene(new Scene(root, 300, 300));
        stage.show();
    }

    // ─────────────── GETTERS ───────────────

    public int getFilas()    { return filas;    }
    public int getColumnas() { return columnas; }
    public Stage getStage()  { return stage;    }
}
