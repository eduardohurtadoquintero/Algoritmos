import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.GridPane;

/**
 * Responsabilidad única: mantener el {@link GridPane} que representa
 * el tablero y colocar en él los botones que {@link VistaFichas} crea.
 *
 * No sabe cómo se ven las fichas ni qué significa un clic; sólo sabe
 * cuántas columnas tiene la cuadrícula y dónde va cada botón.
 */
public class VistaTablero {

    private final GridPane    grid;
    private final ScrollPane  scroll;
    private final VistaFichas fichas;

    public VistaTablero(VistaFichas fichas) {
        this.fichas = fichas;

        grid = new GridPane();
        grid.setHgap(5);
        grid.setVgap(5);
        grid.setPadding(new Insets(10));
        grid.setAlignment(Pos.CENTER);

        scroll = new ScrollPane(grid);
    }

    /**
     * Re-dibuja el tablero completo a partir del estado actual del juego.
     * Navega la lista por nodos; nunca usa un índice entero para
     * acceder a la lista.
     */
    public void renderizar(Juego juego) {
        grid.getChildren().clear();
        fichas.limpiar();

        Tablero tablero = juego.getTablero();
        int     cols    = tablero.getColumnas();

        // Navegación por nodos — el único entero que aparece es la
        // posición de columna/fila de la cuadrícula JavaFX, no un índice
        // de la lista propia.
        Nodo<Casilla> cursor = tablero.getCasillas().getInicio();
        int col  = 0;
        int fila = 0;

        while (cursor != null) {
            Button btn = fichas.crearBoton(cursor);
            grid.add(btn, col, fila);

            col++;
            if (col >= cols) { col = 0; fila++; }

            cursor = cursor.getSig();     // avance por referencia al siguiente nodo
        }
    }

    // ─────────────── GETTERS ───────────────

    public ScrollPane getScrollPane() { return scroll; }
    public GridPane   getGrid()       { return grid;   }
}
