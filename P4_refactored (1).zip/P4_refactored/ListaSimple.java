public class ListaSimple<T> {
    private Nodo<T> inicio;

    public ListaSimple() {
        inicio = null;
    }

    // Insertar al inicio
    public void insertarInicio(T dato) {
        Nodo<T> n = new Nodo<>(dato);
        n.setSig(inicio);
        inicio = n;
    }

    // Insertar al final
    public void insertarFin(T dato) {
        Nodo<T> n = new Nodo<>(dato);

        if (inicio == null) {
            inicio = n;
            return;
        }

        Nodo<T> aux = inicio;
        while (aux.getSig() != null) {
            aux = aux.getSig();
        }
        aux.setSig(n);
    }

    // Eliminar un nodo concreto (por referencia, no por índice)
    public void eliminarNodo(Nodo<T> nodo) {
        if (inicio == null || nodo == null) return;

        if (inicio == nodo) {
            inicio = inicio.getSig();
            return;
        }

        Nodo<T> aux = inicio;
        while (aux.getSig() != null) {
            if (aux.getSig() == nodo) {
                aux.setSig(nodo.getSig());
                return;
            }
            aux = aux.getSig();
        }
    }

    // Eliminar y devolver el último elemento
    public T eliminarUltimo() {
        if (inicio == null) return null;

        if (inicio.getSig() == null) {
            T dato = inicio.getInfo();
            inicio = null;
            return dato;
        }

        Nodo<T> aux = inicio;
        while (aux.getSig().getSig() != null) {
            aux = aux.getSig();
        }

        T dato = aux.getSig().getInfo();
        aux.setSig(null);
        return dato;
    }

    // Obtener inicio
    public Nodo<T> getInicio() {
        return inicio;
    }

    // Tamaño de la lista
    public int size() {
        int count = 0;
        Nodo<T> aux = inicio;
        while (aux != null) {
            count++;
            aux = aux.getSig();
        }
        return count;
    }

    // Verificar si está vacía
    public boolean isEmpty() {
        return inicio == null;
    }

    // Limpiar lista
    public void limpiar() {
        inicio = null;
    }
}