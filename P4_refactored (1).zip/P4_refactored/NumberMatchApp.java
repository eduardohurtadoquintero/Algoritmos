import javafx.application.Application;
import javafx.stage.Stage;

public class NumberMatchApp extends Application {

    @Override
    public void start(Stage stage) {
        Vista vista = new Vista();
        Controlador controlador = new Controlador(vista);

        vista.setControlador(controlador);
        vista.mostrarPantallaInicio(stage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}