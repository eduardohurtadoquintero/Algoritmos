import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.scene.control.Button;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Responsabilidad única: crear, animar y actualizar visualmente
 * los botones que representan las fichas (casillas) del tablero.
 *
 * Esta clase NO sabe nada de layouts, paneles ni estadísticas;
 * sólo maneja el estilo y el ciclo de vida visual de cada ficha.
 */
public class VistaFichas {

    // ── Colores de estado ──
    static final String BTN_NORMAL = "#f0f0f0";
    static final String BTN_HOVER  = "#e0e0e0";
    static final String BTN_SEL    = "#d0d0d0";
    static final String BTN_PISTA  = "#fff59d";
    static final String BTN_ELIM   = "#fafafa";
    static final String BTN_ERROR  = "#ffcccc";

    /** Lista de botones en el orden en que fueron creados (orden de la lista). */
    private final List<Button> botones = new ArrayList<>();

    /** Mapa nodo → botón para acceso O(1) sin recorrer la lista. */
    private final Map<Nodo<Casilla>, Button> mapaNodoBoton = new HashMap<>();

    // ─────────────── ESTADO DE SELECCIÓN ───────────────

    private Nodo<Casilla> seleccion1    = null;
    private Button        btnSeleccion1 = null;

    /** Callback invocado cuando el jugador selecciona dos fichas. */
    private java.util.function.BiConsumer<Nodo<Casilla>, Nodo<Casilla>> alSeleccionarPar;

    public void setAlSeleccionarPar(
            java.util.function.BiConsumer<Nodo<Casilla>, Nodo<Casilla>> cb) {
        this.alSeleccionarPar = cb;
    }

    // ─────────────── CREACIÓN DE FICHAS ───────────────

    /**
     * Crea un botón para el nodo dado y lo registra internamente.
     * El botón es devuelto para que {@link VistaTablero} lo coloque
     * en la posición de cuadrícula correcta.
     */
    public Button crearBoton(Nodo<Casilla> nodo) {
        Casilla c = nodo.getInfo();

        Button btn = new Button();
        btn.setPrefSize(50, 50);

        if (c == null || c.isEliminada()) {
            aplicarEliminado(btn);
        } else {
            btn.setText(String.valueOf(c.getValor()));
            btn.setStyle(estiloFicha(BTN_NORMAL));

            btn.setOnMouseEntered(e -> {
                if (btn != btnSeleccion1) btn.setStyle(estiloFicha(BTN_HOVER));
            });
            btn.setOnMouseExited(e -> {
                if (btn != btnSeleccion1) btn.setStyle(estiloFicha(BTN_NORMAL));
            });
            btn.setOnAction(e -> manejarClick(nodo, btn));
        }

        mapaNodoBoton.put(nodo, btn);
        botones.add(btn);
        return btn;
    }

    /** Vacía las estructuras internas antes de un re-render completo. */
    public void limpiar() {
        botones.clear();
        mapaNodoBoton.clear();
        limpiarSeleccionVisual();
    }

    // ─────────────── MANEJO DE CLICKS ───────────────

    private void manejarClick(Nodo<Casilla> nodo, Button btn) {
        if (btn.isDisabled()) return;

        if (seleccion1 == null) {
            // Primera ficha seleccionada
            seleccion1    = nodo;
            btnSeleccion1 = btn;
            btn.setStyle(estiloFicha(BTN_SEL));

        } else if (seleccion1 == nodo) {
            // Misma ficha — cancelar selección
            limpiarSeleccionVisual();

        } else {
            // Segunda ficha — notificar par al controlador
            Nodo<Casilla> primera = seleccion1;
            limpiarSeleccionVisual();
            if (alSeleccionarPar != null) alSeleccionarPar.accept(primera, nodo);
        }
    }

    public void limpiarSeleccionVisual() {
        if (btnSeleccion1 != null && !btnSeleccion1.isDisabled()) {
            btnSeleccion1.setStyle(estiloFicha(BTN_NORMAL));
        }
        seleccion1    = null;
        btnSeleccion1 = null;
    }

    // ─────────────── ANIMACIONES ───────────────

    /** Anima la eliminación de las dos fichas del par. */
    public void animarEliminacion(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        limpiarSeleccionVisual();
        animar(n1);
        animar(n2);
    }

    private void animar(Nodo<Casilla> nodo) {
        Button b = mapaNodoBoton.get(nodo);
        if (b == null) return;

        FadeTransition ft = new FadeTransition(Duration.millis(200), b);
        ft.setToValue(0);
        ft.setOnFinished(e -> aplicarEliminado(b));
        ft.play();
    }

    /** Resalta brevemente las dos fichas de pista y luego restaura el color. */
    public void resaltarPista(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        Button b1 = mapaNodoBoton.get(n1);
        Button b2 = mapaNodoBoton.get(n2);

        if (b1 != null) b1.setStyle(estiloFicha(BTN_PISTA));
        if (b2 != null) b2.setStyle(estiloFicha(BTN_PISTA));

        PauseTransition p = new PauseTransition(Duration.seconds(1.5));
        p.setOnFinished(e -> {
            if (b1 != null && !b1.isDisabled()) b1.setStyle(estiloFicha(BTN_NORMAL));
            if (b2 != null && !b2.isDisabled()) b2.setStyle(estiloFicha(BTN_NORMAL));
        });
        p.play();
    }

    /** Parpadea en rojo la ficha de una selección inválida. */
    public void mostrarErrorSeleccion(Nodo<Casilla> n1) {
        Button b = mapaNodoBoton.get(n1);
        if (b == null) return;

        b.setStyle(estiloFicha(BTN_ERROR));

        PauseTransition p = new PauseTransition(Duration.millis(350));
        p.setOnFinished(e -> {
            if (!b.isDisabled()) b.setStyle(estiloFicha(BTN_NORMAL));
            limpiarSeleccionVisual();
        });
        p.play();
    }

    // ─────────────── HELPERS VISUALES ───────────────

    private void aplicarEliminado(Button b) {
        b.setOpacity(1);
        b.setText("");
        b.setDisable(true);
        b.setStyle(estiloFicha(BTN_ELIM));
    }

    public static String estiloFicha(String color) {
        return "-fx-background-color:" + color + ";"
             + "-fx-border-color:#888;"
             + "-fx-border-width:2;";
    }

    // ─────────────── GETTERS ───────────────

    public Button botonDe(Nodo<Casilla> nodo) { return mapaNodoBoton.get(nodo); }
}
