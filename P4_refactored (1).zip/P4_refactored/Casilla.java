/**
 * Representa una casilla del tablero de NumberMatch.
 * Implementa Comparable para identificar qué dos casillas concuerdan.
 */
public class Casilla implements Comparable<Casilla> {
    private int valor;
    private boolean eliminada;
    private int fila;
    private int columna;

    public Casilla(int valor, int fila, int columna) {
        this.valor = valor;
        this.eliminada = false;
        this.fila = fila;
        this.columna = columna;
    }

    public int getValor() {
        return valor;
    }

    public boolean isEliminada() {
        return eliminada;
    }

    public void setEliminada(boolean eliminada) {
        this.eliminada = eliminada;
    }

    public int getFila() {
        return fila;
    }

    public void setFila(int fila) {
        this.fila = fila;
    }

    public int getColumna() {
        return columna;
    }

    public void setColumna(int columna) {
        this.columna = columna;
    }

    @Override
    public int compareTo(Casilla otra) {
        if (this.valor == otra.valor || this.valor + otra.valor == 10) {
            return 0; // Concuerdan
        }
        return Integer.compare(this.valor, otra.valor);
    }


    public boolean concuerdaCon(Casilla otra) {
        return this.compareTo(otra) == 0;
    }

    @Override
    public String toString() {
        return String.valueOf(valor);
    }
}