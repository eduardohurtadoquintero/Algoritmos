public class Tablero {
    private ListaSimple<Casilla> casillas;
    private int columnas;

    public Tablero(int columnas) {
        this.columnas = columnas;
        this.casillas = new ListaSimple<>();
    }

    // ─────────────── INICIALIZACIÓN ───────────────

    public void inicializar(int[] numeros) {
        casillas.limpiar();
        // Recorremos el arreglo de entrada y construimos los nodos de la lista
        // sin usar índice entero para navegar la propia lista
        int pos = 0;
        for (int numero : numeros) {
            casillas.insertarFin(new Casilla(numero, pos / columnas, pos % columnas));
            pos++;
        }
    }

    public void agregarCasillas(int[] numeros) {
        // Calculamos la posición base contando los nodos existentes
        int base = casillas.size();
        int pos  = 0;
        for (int numero : numeros) {
            int posAbsoluta = base + pos;
            casillas.insertarFin(new Casilla(numero, posAbsoluta / columnas, posAbsoluta % columnas));
            pos++;
        }
    }

    // ─────────────── ADYACENCIA ───────────────

    public boolean sonAdyacentes(Nodo<Casilla> nodoA, Nodo<Casilla> nodoB) {
        if (nodoA == null || nodoB == null)                                  return false;
        if (nodoA == nodoB)                                                  return false;
        if (nodoA.getInfo() == null || nodoB.getInfo() == null)              return false;
        if (nodoA.getInfo().isEliminada() || nodoB.getInfo().isEliminada())  return false;

        // Determinamos cuál aparece primero en la lista navegando con nodos
        Nodo<Casilla> primero = null;
        Nodo<Casilla> segundo = null;
        Nodo<Casilla> cursor  = casillas.getInicio();

        while (cursor != null) {
            if (cursor == nodoA || cursor == nodoB) {
                if (primero == null) primero = cursor;
                else                { segundo = cursor; break; }
            }
            cursor = cursor.getSig();
        }

        if (primero == null || segundo == null) return false;
        return sonAdyacentesPorNodos(primero, segundo);
    }

    private boolean sonAdyacentesPorNodos(Nodo<Casilla> nodoA, Nodo<Casilla> nodoB) {
        Casilla ca = nodoA.getInfo();
        Casilla cb = nodoB.getInfo();

        int fa   = ca.getFila(),   cola = ca.getColumna();
        int fb   = cb.getFila(),   colb = cb.getColumna();

        // ── Mismo renglón ──
        if (fa == fb) {
            int minC = Math.min(cola, colb);
            int maxC = Math.max(cola, colb);

            // Extremos opuestos del mismo renglón (wrap interno)
            if (minC == 0 && maxC == columnas - 1) return true;

            // No hay casilla activa entre ellas en el mismo renglón
            Nodo<Casilla> cur = nodoA.getSig();
            while (cur != null && cur != nodoB) {
                Casilla mid = cur.getInfo();
                if (mid != null && !mid.isEliminada() && mid.getFila() == fa) return false;
                cur = cur.getSig();
            }
            return true;
        }

        // ── Misma columna ──
        if (cola == colb) {
            Nodo<Casilla> cur = nodoA.getSig();
            while (cur != null && cur != nodoB) {
                Casilla mid = cur.getInfo();
                if (mid != null && !mid.isEliminada() && mid.getColumna() == cola) return false;
                cur = cur.getSig();
            }
            return true;
        }

        // ── Diagonal ──
        if (Math.abs(fb - fa) == Math.abs(colb - cola)) {
            int pasoFila = Integer.compare(fb, fa);
            int pasoCol  = Integer.compare(colb, cola);

            Nodo<Casilla> cur = nodoA.getSig();
            int f = fa + pasoFila;
            int c = cola + pasoCol;

            while (cur != null && cur != nodoB) {
                Casilla mid = cur.getInfo();
                if (mid != null && !mid.isEliminada()
                        && mid.getFila() == f && mid.getColumna() == c) return false;
                if (mid != null && mid.getFila() == f && mid.getColumna() == c) {
                    f += pasoFila;
                    c += pasoCol;
                }
                cur = cur.getSig();
            }
            return true;
        }

        // ── Salto de renglón: última columna → primera columna del siguiente ──
        if (fb == fa + 1 && cola == columnas - 1 && colb == 0) {
            Nodo<Casilla> cur = nodoA.getSig();
            while (cur != null && cur != nodoB) {
                Casilla mid = cur.getInfo();
                if (mid != null && !mid.isEliminada() && mid.getFila() == fa)  return false;
                if (mid != null && !mid.isEliminada() && mid.getFila() == fb
                        && mid.getColumna() < colb)                             return false;
                cur = cur.getSig();
            }
            return true;
        }

        return false;
    }

    // ─────────────── OPERACIONES DE PAR ───────────────

    public boolean eliminarPar(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        if (n1 == null || n2 == null)                                      return false;
        if (n1.getInfo().isEliminada() || n2.getInfo().isEliminada())      return false;
        if (!n1.getInfo().concuerdaCon(n2.getInfo()))                      return false;
        if (!sonAdyacentes(n1, n2))                                        return false;

        n1.getInfo().setEliminada(true);
        n2.getInfo().setEliminada(true);
        return true;
    }

    public void restaurarPar(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        if (n1 != null) n1.getInfo().setEliminada(false);
        if (n2 != null) n2.getInfo().setEliminada(false);
    }

    // ─────────────── BÚSQUEDA / PISTA ───────────────

    /**
     * Busca una pista navegando con nodos — sin usar índices enteros.
     * Retorna el par [nodoA, nodoB] que concuerda y es adyacente, o null.
     */
    public Nodo<Casilla>[] buscarPista() {
        Nodo<Casilla> curA = casillas.getInicio();

        while (curA != null) {
            Casilla ca = curA.getInfo();
            if (ca != null && !ca.isEliminada()) {
                Nodo<Casilla> curB = curA.getSig();
                while (curB != null) {
                    Casilla cb = curB.getInfo();
                    if (cb != null && !cb.isEliminada()
                            && ca.concuerdaCon(cb)
                            && sonAdyacentesPorNodos(curA, curB)) {
                        @SuppressWarnings("unchecked")
                        Nodo<Casilla>[] par = new Nodo[]{curA, curB};
                        return par;
                    }
                    curB = curB.getSig();
                }
            }
            curA = curA.getSig();
        }
        return null;
    }

    // ─────────────── CONSULTAS ───────────────

    public boolean hayMovimientosPosibles() { return buscarPista() != null; }

    public int contarMovimientosPosibles() {
        int count = 0;
        Nodo<Casilla> curA = casillas.getInicio();
        while (curA != null) {
            Casilla ca = curA.getInfo();
            if (ca != null && !ca.isEliminada()) {
                Nodo<Casilla> curB = curA.getSig();
                while (curB != null) {
                    Casilla cb = curB.getInfo();
                    if (cb != null && !cb.isEliminada()
                            && ca.concuerdaCon(cb)
                            && sonAdyacentesPorNodos(curA, curB)) count++;
                    curB = curB.getSig();
                }
            }
            curA = curA.getSig();
        }
        return count;
    }

    public boolean estaCompleto() {
        Nodo<Casilla> cur = casillas.getInicio();
        while (cur != null) {
            if (cur.getInfo() != null && !cur.getInfo().isEliminada()) return false;
            cur = cur.getSig();
        }
        return true;
    }

    public int contarActivas() {
        int count = 0;
        Nodo<Casilla> cur = casillas.getInicio();
        while (cur != null) {
            if (cur.getInfo() != null && !cur.getInfo().isEliminada()) count++;
            cur = cur.getSig();
        }
        return count;
    }

    // ─────────────── GETTERS ───────────────

    public int                  getTotalCasillas() { return casillas.size(); }
    public int                  getColumnas()      { return columnas; }
    public int                  getFilas()         { return (int) Math.ceil((double) casillas.size() / columnas); }
    public ListaSimple<Casilla> getCasillas()      { return casillas; }
}
