public class Controlador {
    private Juego juego;
    private Vista vista;
  
    public Controlador(Vista vista) {
        this.vista = vista;
    }

    public void iniciarJuego(int filas, int columnas) {
        juego = new Juego(filas, columnas);
        juego.iniciar();
        vista.renderizarTablero(juego);
        vista.actualizarEstadisticas(juego);
    }

    public void seleccionarCasilla(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        if (juego == null) return;
        boolean exito = juego.realizarMovimiento(n1, n2);
        if (exito) {
            vista.animarEliminacion(n1, n2);
            vista.actualizarEstadisticas(juego);
            if (juego.estaCompleto()) {
                vista.mostrarVictoria(juego);
            } else if (!juego.hayMovimientosPosibles()) {
                vista.mostrarSinMovimientos();
            }
        } else {
            vista.mostrarErrorSeleccion(n1);
        }
    }

    public void deshacerMovimiento() {
        if (juego == null) return;
        if (juego.deshacerMovimiento()) {
            vista.renderizarTablero(juego);
            vista.actualizarEstadisticas(juego);
        }
    }

    public void mostrarPista() {
        if (juego == null) return;
        Nodo<Casilla>[] pista = juego.obtenerPista();
        if (pista != null) {
            vista.resaltarPista(pista[0], pista[1]);
        } else {
            vista.mostrarMensaje("No hay movimientos posibles.");
        }
    }

    public void agregarNumeros() {
        if (juego == null) return;
        boolean exito = juego.agregarNumeros();
        if (exito) {
            vista.renderizarTablero(juego);
            vista.actualizarEstadisticas(juego);
            vista.actualizarUsosMasNumeros(juego.getUsosAgregarRestantes());
        } else {
            vista.mostrarMensaje("Ya no puedes agregar más números (límite de "
                + Juego.MAX_USOS_AGREGAR + " usos alcanzado).");
        }
    }
}