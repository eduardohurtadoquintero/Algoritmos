import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.BorderPane;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 * Vista principal del juego NumberMatch.
 *
 * Actúa como coordinadora de las tres subvistas especializadas:
 * <ul>
 *   <li>{@link VistaPantallaTitulo} — pantalla de inicio y configuración.</li>
 *   <li>{@link VistaTablero}        — cuadrícula de casillas (GridPane).</li>
 *   <li>{@link VistaFichas}         — creación, estilo y animaciones de fichas.</li>
 *   <li>{@link VistaPanel}          — barra superior y panel lateral de controles.</li>
 * </ul>
 *
 * Vista no contiene lógica de negocio; todo evento de UI lo delega
 * al {@link Controlador} mediante los métodos públicos de esta clase.
 */
public class Vista {

    private Controlador controlador;

    // ── Subvistas ──
    private VistaPantallaTitulo pantallaTitulo;
    private VistaTablero        vistaTablero;
    private VistaFichas         vistaFichas;
    private VistaPanel          vistaPanel;

    public void setControlador(Controlador c) {
        this.controlador = c;
    }

    // ─────────────── INICIO ───────────────

    public void mostrarPantallaInicio(Stage stage) {
        pantallaTitulo = new VistaPantallaTitulo(stage);
        pantallaTitulo.setAlIniciar(this::iniciarPantallaJuego);
        pantallaTitulo.mostrar();
    }

    // ─────────────── JUEGO ───────────────

    private void iniciarPantallaJuego() {
        int filas    = pantallaTitulo.getFilas();
        int columnas = pantallaTitulo.getColumnas();
        Stage stage  = pantallaTitulo.getStage();

        // Crear subvistas especializadas
        vistaFichas  = new VistaFichas();
        vistaTablero = new VistaTablero(vistaFichas);
        vistaPanel   = new VistaPanel();

        // Conectar callback de selección de par → Controlador
        vistaFichas.setAlSeleccionarPar(
            (n1, n2) -> controlador.seleccionarCasilla(n1, n2)
        );

        // Conectar callbacks de botones → Controlador
        vistaPanel.setAlPista(   () -> controlador.mostrarPista());
        vistaPanel.setAlDeshacer(() -> controlador.deshacerMovimiento());
        vistaPanel.setAlAgregar( () -> controlador.agregarNumeros());

        // Componer layout
        BorderPane root = new BorderPane();
        root.setTop(vistaPanel.getTopBar());
        root.setCenter(vistaTablero.getScrollPane());
        root.setRight(vistaPanel.getPanelLateral());

        double anchoP = Screen.getPrimary().getVisualBounds().getWidth();
        double altoP  = Screen.getPrimary().getVisualBounds().getHeight();
        double anchoV = Math.min(anchoP * 0.95, columnas * 58 + 200.0);
        double altoV  = Math.min(altoP  * 0.92, filas    * 58 + 100.0);

        stage.setScene(new Scene(root, anchoV, altoV));

        // El controlador inicializa la lógica y luego invoca renderizarTablero
        controlador.iniciarJuego(filas, columnas);
    }

    // ─────────────── RENDER ───────────────

    /** Solicita al VistaTablero que redibuje toda la cuadrícula. */
    public void renderizarTablero(Juego juego) {
        vistaTablero.renderizar(juego);
        vistaPanel.actualizarEstadisticas(juego);
    }

    // ─────────────── ESTADÍSTICAS ───────────────

    public void actualizarEstadisticas(Juego juego) {
        vistaPanel.actualizarEstadisticas(juego);
    }

    public void actualizarUsosMasNumeros(int usos) {
        vistaPanel.actualizarUsosMasNumeros(usos);
    }

    // ─────────────── ANIMACIONES / FEEDBACK ───────────────

    public void animarEliminacion(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        vistaFichas.animarEliminacion(n1, n2);
    }

    public void resaltarPista(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        vistaFichas.resaltarPista(n1, n2);
    }

    public void mostrarErrorSeleccion(Nodo<Casilla> n1) {
        vistaFichas.mostrarErrorSeleccion(n1);
    }

    // ─────────────── MENSAJES ───────────────

    public void mostrarMensaje(String msg) {
        new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
    }

    public void mostrarVictoria(Juego juego) {
        mostrarMensaje("¡Ganaste! Concordancias: " + juego.getConcordanciasEncontradas());
    }

    public void mostrarSinMovimientos() {
        mostrarMensaje("Sin movimientos disponibles.");
    }
}
