import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * Responsabilidad única: construir y actualizar los controles
 * de información y acción del juego:
 * <ul>
 *   <li>Barra superior — logo y mensaje de estado.</li>
 *   <li>Panel lateral — contador de concordancias y botones
 *       de Pista, Deshacer y Agregar números.</li>
 * </ul>
 *
 * Recibe callbacks para comunicar los eventos de los botones
 * al controlador sin acoplarse a él directamente.
 */
public class VistaPanel {

    // ── Barra superior ──
    private final HBox  topBar;
    private final Label lblEstado;

    // ── Panel lateral ──
    private final VBox   panelLateral;
    private final Label  lblEncontradas;
    private final Button btnAgregar;

    // ── Callbacks → Controlador ──
    private Runnable alPista;
    private Runnable alDeshacer;
    private Runnable alAgregar;

    public VistaPanel() {
        // ── Barra superior ──
        topBar = new HBox(10);
        topBar.setPadding(new Insets(10));

        Label logo = new Label("NumberMatch");
        logo.setFont(Font.font("Arial", FontWeight.BOLD, 16));

        lblEstado = new Label("Selecciona una casilla");

        topBar.getChildren().addAll(logo, lblEstado);

        // ── Panel lateral ──
        panelLateral   = new VBox(10);
        panelLateral.setPadding(new Insets(10));

        lblEncontradas = new Label("0");

        Button btnPista    = new Button("Pista");
        Button btnDeshacer = new Button("Deshacer");
        btnAgregar         = new Button("+");

        btnPista.setPrefWidth(120);
        btnDeshacer.setPrefWidth(120);
        btnAgregar.setPrefWidth(120);

        btnPista.setOnAction(e    -> { if (alPista    != null) alPista.run(); });
        btnDeshacer.setOnAction(e -> { if (alDeshacer != null) alDeshacer.run(); });
        btnAgregar.setOnAction(e  -> { if (alAgregar  != null) alAgregar.run(); });

        panelLateral.getChildren().addAll(
                new Label("Encontradas"), lblEncontradas,
                btnPista, btnDeshacer, btnAgregar
        );
    }

    // ─────────────── ACTUALIZACIÓN ───────────────

    /** Actualiza las estadísticas visibles con los datos actuales del juego. */
    public void actualizarEstadisticas(Juego juego) {
        lblEncontradas.setText(String.valueOf(juego.getConcordanciasEncontradas()));
        actualizarBtnAgregar(juego.getUsosAgregarRestantes());
    }

    public void actualizarUsosMasNumeros(int usos) {
        actualizarBtnAgregar(usos);
    }

    private void actualizarBtnAgregar(int usos) {
        btnAgregar.setText("+ (" + usos + ")");
        btnAgregar.setDisable(usos <= 0);
    }

    public void setMensajeEstado(String msg) {
        lblEstado.setText(msg);
    }

    // ─────────────── REGISTRO DE CALLBACKS ───────────────

    public void setAlPista(Runnable cb)    { this.alPista    = cb; }
    public void setAlDeshacer(Runnable cb) { this.alDeshacer = cb; }
    public void setAlAgregar(Runnable cb)  { this.alAgregar  = cb; }

    // ─────────────── GETTERS ───────────────

    public HBox  getTopBar()       { return topBar;       }
    public VBox  getPanelLateral() { return panelLateral; }
}
