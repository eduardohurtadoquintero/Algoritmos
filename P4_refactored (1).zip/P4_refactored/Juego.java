import java.util.Random;

public class Juego {
    private Tablero tablero;

    private ListaSimple<Nodo[]> historialMovimientos;

    private int columnas;
    private int filas;

    public static final int MAX_USOS_AGREGAR = 3;
    private int usosAgregarRestantes = MAX_USOS_AGREGAR;

    private static final int[] POOL = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    private static final Random RNG  = new Random();

    public Juego(int filas, int columnas) {
        this.filas    = filas;
        this.columnas = columnas;
        this.tablero  = new Tablero(columnas);
        this.historialMovimientos = new ListaSimple<>();
    }

    public void iniciar() {
        tablero.inicializar(generarNumeros(filas * columnas));
    }

    private int[] generarNumeros(int cantidad) {
        int[] res = new int[cantidad];
        for (int i = 0; i < cantidad; i++) res[i] = POOL[RNG.nextInt(POOL.length)];
        return res;
    }

    public boolean agregarNumeros() {
        if (usosAgregarRestantes <= 0) return false;
        tablero.agregarCasillas(generarNumeros(20));
        usosAgregarRestantes--;
        return true;
    }


    public boolean realizarMovimiento(Nodo<Casilla> n1, Nodo<Casilla> n2) {
        if (tablero.eliminarPar(n1, n2)) {
            historialMovimientos.insertarFin(new Nodo[]{n1, n2});
            return true;
        }
        return false;
    }


    public boolean deshacerMovimiento() {
        if (historialMovimientos.isEmpty()) return false;
        // eliminarUltimo saca y devuelve el último par de nodos en un solo paso
        Nodo[] ultimo = historialMovimientos.eliminarUltimo();
        tablero.restaurarPar(
            (Nodo<Casilla>) ultimo[0],
            (Nodo<Casilla>) ultimo[1]
        );
        return true;
    }

    public Nodo<Casilla>[] obtenerPista()           { return tablero.buscarPista(); }
    public boolean hayMovimientosPosibles()          { return tablero.hayMovimientosPosibles(); }
    public boolean estaCompleto()                    { return tablero.estaCompleto(); }
    public Tablero getTablero()                      { return tablero; }
    public int     getConcordanciasEncontradas()     { return tablero.contarMovimientosPosibles(); }
    public int     getConcordanciasPendientes()      { return tablero.contarActivas() / 2; }
    public int     getColumnas()                     { return columnas; }
    public int     getFilas()                        { return filas; }
    public boolean hayHistorial()                    { return !historialMovimientos.isEmpty(); }
    public int     getUsosAgregarRestantes()         { return usosAgregarRestantes; }
    public boolean puedeAgregarNumeros()             { return usosAgregarRestantes > 0; }
}