import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LectorCSV {

    public ArrayList<Juego> leerJuegos(String archivo) {

        ArrayList<Juego> juegos = new ArrayList<>();

        try {

            BufferedReader reader = new BufferedReader(new FileReader(archivo));

            String linea;

            reader.readLine(); // Saltar encabezados

            while ((linea = reader.readLine()) != null) {

                String[] parts = linea.split(",");

                String title = parts[1];
                String releaseDate = parts[2];
                double rating = Double.parseDouble(parts[4]);

                Juego juego = new Juego(title, releaseDate, rating);

                juegos.add(juego);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return juegos;
    }
}