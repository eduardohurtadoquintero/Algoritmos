public class Juego {

    String title;
    String releaseDate;
    double rating;

    public Juego(String title, String releaseDate, double rating) {

        this.title = title;
        this.releaseDate = releaseDate;
        this.rating = rating;
    }

    public String getTitle() {
        return title;
    }

    public double getRating() {
        return rating;
    }
}