public record ArrayList() {

}
