import java.util.ArrayList;
public class Main {

    public static void main(String[] args) {

        LectorCSV lector = new LectorCSV();

        ArrayList<Juego> juegos = lector.leerJuegos("games.csv");

        Ordenamientos ord = new Ordenamientos();

        // ORDENAR
        int[] ratings = juegos.stream().mapToInt(j -> j.getRating()).toArray();
        ord.shellSort(ratings);

        // MOSTRAR
        System.out.println("Arreglo ordenado:");

        for (int num : juegos.stream().mapToInt(Juego::getRating).toArray()) {
            System.out.println(num);
        }
    }
}