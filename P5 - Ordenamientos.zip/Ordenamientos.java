import java.util.List;
import java.util.ArrayList;

public class Ordenamientos{ 

//SHELLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL

public void shellSort(int[] arreglo) {

    int n = arreglo.length;
    int inter = n + 1;
    int band;
    int i;

    while (inter > 1) {

        inter = inter / 2;
        band = 1;

        while (band == 1) {

            band = 0;
            i = 0;

            while ((i + inter) < n) {

                if (arreglo[i] > arreglo[i + inter]) {

                    int temp = arreglo[i];
                    arreglo[i] = arreglo[i + inter];
                    arreglo[i + inter] = temp;

                    band = 1;
                }

                i++;
            }
        }
    }
}

//MERGE SORTttttttttttttttttttttttttttttttttttt

public int[] MergeSort(int[] arreglo) {

    // Caso base
    if (arreglo.length <= 1) {
        return arreglo;
    }

    // Punto medio
    int mid = arreglo.length / 2;

    // Crear subarreglos
    int[] left = new int[mid];
    int[] right = new int[arreglo.length - mid];

    // Copiar datos a izquierda
    for (int i = 0; i < mid; i++) {
        left[i] = arreglo[i];
    }

    // Copiar datos a derecha
    for (int i = mid; i < arreglo.length; i++) {
        right[i - mid] = arreglo[i];
    }

    // Llamadas recursivas
    left = MergeSort(left);
    right = MergeSort(right);

    // Combinar
    return merge(left, right);
}

public int[] merge(int[] left, int[] right) {

    int[] result = new int[left.length + right.length];

    int i = 0;
    int j = 0;
    int k = 0;

    // Comparar elementos
    while (i < left.length && j < right.length) {

        if (left[i] <= right[j]) {
            result[k] = left[i];
            i++;
        } else {
            result[k] = right[j];
            j++;
        }

        k++;
    }

    // Copiar sobrantes izquierda
    while (i < left.length) {
        result[k] = left[i];
        i++;
        k++;
    }

    // Copiar sobrantes derecha
    while (j < right.length) {
        result[k] = right[j];
        j++;
        k++;
    }

    return result;
}
//---------------------------------------------------------
//RADIXSORTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
//---------------------------------------------------------
public void radixSort(int[] A, int cantDigitos){
int exp = 1;
int pasada = 1;
  
while (pasada <= cantDigitos){
    List<Integer>[] buckets = new ArrayList[10];
    for (int i = 0; i < 10; i++) {
        buckets[i] = new ArrayList<>();
    }

    for (int i = 0; i < A.length; i++) {
        int digito = (A[i] / exp) % 10;
        buckets[digito].add(A[i]);
    }

    int pos = 0;
    for (int i = 0; i < 10; i++) {
        for (int num : buckets[i]) {
            A[pos] = num;
            pos++;
        }
    }
    exp *= 10;
    pasada++;
}
}

//QUICK SORT RECURSIVOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

int[] A;

public void quickSort(int[] arreglo, int N) {

    A = arreglo;

    recursivo(0, N - 1);
}

public void recursivo(int ini, int fin) {

    int izq = ini;
    int der = fin;
    int pos = ini;
    boolean band = true;

    while (band == true) {

        band = false;

        // Paso 2.1
        while (A[pos] <= A[der] && pos != der) {
            der--;
        }

        // Paso 2.3
        if (pos != der) {

            int aux = A[pos];
            A[pos] = A[der];
            A[der] = aux;

            pos = der;

            // Paso 2.3.1
            while (A[pos] >= A[izq] && pos != izq) {
                izq++;
            }

            // Paso 2.3.3
            if (pos != izq) {

                band = true;

                aux = A[pos];
                A[pos] = A[izq];
                A[izq] = aux;

                pos = izq;
            }
        }
    }

    // Paso 4
    if ((pos - 1) > ini) {
        recursivo(ini, pos - 1);
    }

    // Paso 6
    if (fin > (pos + 1)) {
        recursivo(pos + 1, fin);
    }
}

public void SeleccionDirecta(int[] arreglo) {

    int n = arreglo.length;

    for (int i = 0; i < n - 1; i++) {
        int minIndex = i;

        for (int j = i + 1; j < n; j++) {
            if (arreglo[j] < arreglo[minIndex]) {
                minIndex = j;
            }
        }

        // Intercambiar el elemento mínimo con el primer elemento
        int temp = arreglo[minIndex];
        arreglo[minIndex] = arreglo[i];
        arreglo[i] = temp;
    }

}
}