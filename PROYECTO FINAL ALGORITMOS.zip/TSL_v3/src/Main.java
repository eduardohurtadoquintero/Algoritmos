import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║   GRAFO DIRIGIDO ACICLICO - MENU PRINCIPAL   ║");
        System.out.println("╚══════════════════════════════════════════════╝");

        GrafoDirigidoAciclico grafo = null;
        boolean salir = false;

        while (!salir) {
            System.out.println("\n┌─────────────────────────────────┐");
            System.out.println("│            OPCIONES             │");
            System.out.println("├─────────────────────────────────┤");
            System.out.println("│ 1.  Crear nuevo grafo           │");
            System.out.println("│ 2.  Insertar arista             │");
            System.out.println("│ 3.  Grado de entrada            │");
            System.out.println("│ 4.  Grado de salida             │");
            System.out.println("│ 5.  Cuantas aristas hay         │");
            System.out.println("│ 6.  Estan conectados?           │");
            System.out.println("│ 7.  Topological Sort            │");
            System.out.println("│ 8.  Mostrar matriz              │");
            System.out.println("│ 9.  Eliminar todas las aristas  │");
            System.out.println("│ 10. Grafo de demostracion       │");
            System.out.println("│ 0.  Salir                       │");
            System.out.println("└─────────────────────────────────┘");
            System.out.print("Opcion: ");

            int op = leerInt(sc);

            switch (op) {

                case 1 -> {
                    System.out.print("Cuantos vertices tendra el grafo? ");
                    int n = leerInt(sc);
                    if (n <= 0) { System.out.println("Debe ser mayor a 0."); break; }

                    grafo = new GrafoDirigidoAciclico(n);

                    System.out.println("Ingresa el nombre de cada vertice:");
                    for (int i = 0; i < n; i++) {
                        System.out.print("  Nombre del vertice [" + i + "]: ");
                        String nombre = sc.nextLine().trim();
                        if (nombre.isEmpty()) nombre = String.valueOf(i);
                        grafo.setNombre(i, nombre);
                    }

                    System.out.println("\nGrafo creado con " + n + " vertices:");
                    for (int i = 0; i < n; i++)
                        System.out.println("  [" + i + "] -> " + grafo.getNombre(i));
                }

                case 2 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    mostrarVertices(grafo);
                    System.out.print("Indice vertice ORIGEN  (i): ");
                    int i = leerInt(sc);
                    System.out.print("Indice vertice DESTINO (j): ");
                    int j = leerInt(sc);
                    try {
                        boolean ok = grafo.insertarArista(i, j);
                        if (ok)
                            System.out.println("Arista " + grafo.getNombre(i)
                                + " -> " + grafo.getNombre(j) + " insertada.");
                        else
                            System.out.println("No se pudo insertar"
                                + " (duplicada, auto-arista o ciclo).");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                }

                case 3 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    System.out.println("=== GRADO DE ENTRADA ===");
                    for (int i = 0; i < grafo.getNumVertices(); i++)
                        System.out.println("  [" + grafo.getNombre(i) + "]: "
                            + grafo.gradoDeEntrada(i));
                }

                case 4 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    System.out.println("=== GRADO DE SALIDA ===");
                    for (int i = 0; i < grafo.getNumVertices(); i++)
                        System.out.println("  [" + grafo.getNombre(i) + "]: "
                            + grafo.gradoDeSalida(i));
                }

                case 5 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    System.out.println("Total de aristas: " + grafo.cuantasAristasHay());
                }

                case 6 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    mostrarVertices(grafo);
                    System.out.print("Indice origen i: ");  int i = leerInt(sc);
                    System.out.print("Indice destino j: "); int j = leerInt(sc);
                    try {
                        boolean r = grafo.conectados(i, j);
                        System.out.println("Camino de [" + grafo.getNombre(i) + "] a ["
                            + grafo.getNombre(j) + "]? " + (r ? "SI" : "NO"));
                    } catch (IllegalArgumentException e) { System.out.println("Error: " + e.getMessage()); }
                }

                case 7 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    System.out.println("\n=== ORDENAMIENTO TOPOLOGICO ===");
                    System.out.println(grafo.topologicalSort());
                }

                case 8 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    System.out.println("=== MATRIZ DE ADYACENCIA ===");
                    grafo.mostrarEstructura();
                }

                case 9 -> {
                    if (grafo == null) { sinGrafo(); break; }
                    System.out.print("Eliminar TODAS las aristas? (s/n): ");
                    String c = sc.nextLine().trim().toLowerCase();
                    if (c.equals("s")) {
                        grafo.eliminarAristas();
                        System.out.println("Aristas eliminadas. Total: " + grafo.cuantasAristasHay());
                    } else System.out.println("Cancelado.");
                }

                case 10 -> {
                    System.out.println("\nSelecciona grafo de demostracion:");
                    System.out.println("  a) Grafo con letras del PDF (B,E,A,D,C)");
                    System.out.println("  b) Grafo con numeros del PDF (0,1,2,3)");
                    System.out.println("  c) Grafo de 6 vertices");
                    System.out.print("Opcion (a/b/c): ");
                    String sub = sc.nextLine().trim().toLowerCase();

                    switch (sub) {
                        case "a" -> {
                            grafo = new GrafoDirigidoAciclico(5);
                            grafo.setNombre(0, "B"); grafo.setNombre(1, "E");
                            grafo.setNombre(2, "A"); grafo.setNombre(3, "D");
                            grafo.setNombre(4, "C");
                            grafo.insertarArista(0, 1); grafo.insertarArista(0, 4);
                            grafo.insertarArista(1, 2); grafo.insertarArista(1, 4);
                            grafo.insertarArista(2, 3); grafo.insertarArista(4, 3);
                            System.out.println("Grafo con letras cargado (B=0, E=1, A=2, D=3, C=4).");
                        }
                        case "b" -> {
                            grafo = new GrafoDirigidoAciclico(4);
                            grafo.insertarArista(0, 2); grafo.insertarArista(0, 1);
                            grafo.insertarArista(2, 3); grafo.insertarArista(1, 3);
                            System.out.println("Grafo con numeros cargado.");
                        }
                        default -> {
                            grafo = new GrafoDirigidoAciclico(6);
                            grafo.insertarArista(0, 1); grafo.insertarArista(0, 2);
                            grafo.insertarArista(1, 3); grafo.insertarArista(2, 3);
                            grafo.insertarArista(3, 4); grafo.insertarArista(4, 5);
                            System.out.println("Grafo de 6 vertices cargado.");
                        }
                    }
                    System.out.println("Usa las opciones del menu para probarlo.");
                }

                case 0 -> { System.out.println("Hasta luego!"); salir = true; }

                default -> System.out.println("Opcion invalida.");
            }
        }
        sc.close();
    }

    private static void sinGrafo() {
        System.out.println("Primero crea un grafo (opcion 1 o 10).");
    }

    private static void mostrarVertices(GrafoDirigidoAciclico g) {
        System.out.println("Vertices disponibles:");
        for (int i = 0; i < g.getNumVertices(); i++)
            System.out.println("  [" + i + "] " + g.getNombre(i));
    }

    private static int leerInt(Scanner sc) {
        try {
            return Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
