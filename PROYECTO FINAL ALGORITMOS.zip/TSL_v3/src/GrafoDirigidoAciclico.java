/**
 * Grafo Dirigido Aciclico (DAG) representado mediante LISTAS DE ADYACENCIA
 * construidas exclusivamente con ListaSimple<T> y Nodo<T>.
 *
 * Estructura interna:
 *   - listaAdyacencia : ListaSimple de Entradas; cada Entrada guarda
 *                       el indice del vertice origen y una ListaSimple<Integer>
 *                       con los indices de sus vecinos.
 *   - gradoEntrada    : ListaSimple<Integer> paralela; posicion i -> grado de entrada del vertice i.
 *   - gradoSalida     : ListaSimple<Integer> paralela; posicion i -> grado de salida del vertice i.
 *
 * Los vertices se identifican por un indice 0..n-1.
 * El nombre visible (String) se guarda en la ListaSimple<String> nombreVertices.
 */
public class GrafoDirigidoAciclico {

    // -- Clase interna: entrada de la lista de adyacencia ---------------------
    private static class EntradaAdyacencia {
        int vertice;
        ListaSimple<Integer> vecinos;

        EntradaAdyacencia(int vertice) {
            this.vertice = vertice;
            this.vecinos = new ListaSimple<>();
        }
    }

    // -- Atributos ------------------------------------------------------------
    private final int numVertices;
    private int numAristas;

    private final ListaSimple<EntradaAdyacencia> listaAdyacencia;
    private final ListaSimple<Integer>           gradoEntrada;
    private final ListaSimple<Integer>           gradoSalida;
    private final ListaSimple<String>            nombreVertices;

    // -- Constructor ----------------------------------------------------------
    public GrafoDirigidoAciclico(int n) {
        this.numVertices     = n;
        this.numAristas      = 0;
        this.listaAdyacencia = new ListaSimple<>();
        this.gradoEntrada    = new ListaSimple<>();
        this.gradoSalida     = new ListaSimple<>();
        this.nombreVertices  = new ListaSimple<>();

        for (int i = 0; i < n; i++) {
            listaAdyacencia.insertarFin(new EntradaAdyacencia(i));
            gradoEntrada.insertarFin(0);
            gradoSalida.insertarFin(0);
            nombreVertices.insertarFin(String.valueOf(i));
        }
    }

    // -- Nombres de vertices --------------------------------------------------
    public void setNombre(int i, String nombre) {
        validar(i);
        Nodo<String> aux = nombreVertices.getInicio(); int pos = 0;
        while (aux != null) {
            if (pos == i) { aux.setInfo(nombre); return; }
            aux = aux.getSig(); pos++;
        }
    }

    public String getNombre(int i) { return nombreVertices.get(i); }

    // -- Validacion -----------------------------------------------------------
    private void validar(int i) {
        if (i < 0 || i >= numVertices)
            throw new IllegalArgumentException(
                "Indice fuera de rango: " + i + " (rango valido 0.." + (numVertices - 1) + ")");
    }

    // -- Acceso a EntradaAdyacencia -------------------------------------------
    private EntradaAdyacencia getEntrada(int i) { return listaAdyacencia.get(i); }

    // -- Acceso/modificacion de grados ----------------------------------------
    private int getGradoEntrada(int i) { return gradoEntrada.get(i); }

    private void setGradoEntrada(int i, int valor) {
        Nodo<Integer> aux = gradoEntrada.getInicio(); int pos = 0;
        while (aux != null) {
            if (pos == i) { aux.setInfo(valor); return; }
            aux = aux.getSig(); pos++;
        }
    }

    private int getGradoSalida(int i) { return gradoSalida.get(i); }

    private void setGradoSalida(int i, int valor) {
        Nodo<Integer> aux = gradoSalida.getInicio(); int pos = 0;
        while (aux != null) {
            if (pos == i) { aux.setInfo(valor); return; }
            aux = aux.getSig(); pos++;
        }
    }

    // =========================================================================
    //  METODOS DE ACCESO
    // =========================================================================

    public int gradoDeEntrada(int i) { validar(i); return getGradoEntrada(i); }
    public int gradoDeSalida(int i)  { validar(i); return getGradoSalida(i); }
    public int cuantasAristasHay()   { return numAristas; }

    public boolean adyacente(int i, int j) {
        validar(i); validar(j);
        return getEntrada(i).vecinos.contiene(j);
    }

    /**
     * Regresa true si existe un camino (directo o indirecto) de i a j.
     * BFS usando ColaCircular como cola FIFO.
     */
    public boolean conectados(int i, int j) {
        validar(i); validar(j);
        if (i == j) return true;

        ColaCircular<Integer> cola     = new ColaCircular<>(numVertices);
        ListaSimple<Integer>  visitado = new ListaSimple<>();

        cola.insertar(i);
        visitado.insertarFin(i);

        while (!cola.estaVacia()) {
            int actual = cola.eliminar();
            Nodo<Integer> vecino = getEntrada(actual).vecinos.getInicio();
            while (vecino != null) {
                int v = vecino.getInfo();
                if (v == j) return true;
                if (!visitado.contiene(v)) {
                    visitado.insertarFin(v);
                    cola.insertar(v);
                }
                vecino = vecino.getSig();
            }
        }
        return false;
    }

    /**
     * Ordenamiento Topologico — algoritmo de Kahn.
     *
     * En cada iteracion busca linealmente el vertice con grado 0
     * de menor indice aun no procesado (marcado con -1 al procesarlo).
     * No utiliza ColaPrioridad ni ColaCircular auxiliar.
     *
     * Devuelve una cadena con los NOMBRES de vertices separados por " - ".
     */
    public String topologicalSort() {
        // Copia local de grados de entrada
        ListaSimple<Integer> gradoActual = new ListaSimple<>();
        for (int v = 0; v < numVertices; v++)
            gradoActual.insertarFin(getGradoEntrada(v));

        ListaSimple<Integer> orden = new ListaSimple<>();

        for (int procesados = 0; procesados < numVertices; procesados++) {

            // Buscar linealmente el primer vertice con grado 0
            int actual = -1;
            for (int v = 0; v < numVertices; v++) {
                if (gradoActual.get(v) == 0) { actual = v; break; }
            }
            if (actual == -1) break; // no deberia ocurrir en un DAG valido

            // Marcar como procesado con -1
            Nodo<Integer> nAux = gradoActual.getInicio(); int pos = 0;
            while (nAux != null) {
                if (pos == actual) { nAux.setInfo(-1); break; }
                nAux = nAux.getSig(); pos++;
            }
            orden.insertarFin(actual);

            // Reducir grado de cada vecino
            Nodo<Integer> vecino = getEntrada(actual).vecinos.getInicio();
            while (vecino != null) {
                int v = vecino.getInfo();
                int nuevoGrado = gradoActual.get(v) - 1;
                Nodo<Integer> nVec = gradoActual.getInicio(); int p = 0;
                while (nVec != null) {
                    if (p == v) { nVec.setInfo(nuevoGrado); break; }
                    nVec = nVec.getSig(); p++;
                }
                vecino = vecino.getSig();
            }
        }

        // Construir String con nombres
        StringBuilder sb = new StringBuilder();
        Nodo<Integer> n = orden.getInicio();
        while (n != null) {
            sb.append(getNombre(n.getInfo()));
            if (n.getSig() != null) sb.append(" - ");
            n = n.getSig();
        }
        return sb.toString();
    }

    /**
     * Regresa true si el grafo tiene ciclos (DFS con colores).
     */
    public boolean tieneCiclos() {
        ListaSimple<Integer> estado = new ListaSimple<>();
        for (int v = 0; v < numVertices; v++) estado.insertarFin(0);

        for (int v = 0; v < numVertices; v++)
            if (estado.get(v) == 0 && dfsCiclo(v, estado)) return true;

        return false;
    }

    private boolean dfsCiclo(int v, ListaSimple<Integer> estado) {
        setEstado(estado, v, 1);
        Nodo<Integer> vecino = getEntrada(v).vecinos.getInicio();
        while (vecino != null) {
            int w = vecino.getInfo();
            int est = estado.get(w);
            if (est == 1) return true;
            if (est == 0 && dfsCiclo(w, estado)) return true;
            vecino = vecino.getSig();
        }
        setEstado(estado, v, 2);
        return false;
    }

    private void setEstado(ListaSimple<Integer> estado, int i, int valor) {
        Nodo<Integer> aux = estado.getInicio(); int pos = 0;
        while (aux != null) {
            if (pos == i) { aux.setInfo(valor); return; }
            aux = aux.getSig(); pos++;
        }
    }

    /**
     * Devuelve la representacion del grafo como matriz de adyacencia en String.
     */
    public String mostrarEstructura() {
        StringBuilder sb = new StringBuilder();

        sb.append("Vertices: ");
        for (int i = 0; i < numVertices; i++) {
            sb.append(getNombre(i));
            if (i < numVertices - 1) sb.append(" | ");
        }
        sb.append("\n\n");

        sb.append("     ");
        for (int j = 0; j < numVertices; j++)
            sb.append(String.format("%-4s", getNombre(j)));
        sb.append("\n");

        sb.append("    ");
        sb.append("-".repeat(numVertices * 4)).append("\n");

        for (int i = 0; i < numVertices; i++) {
            sb.append(String.format("%-4s", getNombre(i))).append("|");
            for (int j = 0; j < numVertices; j++)
                sb.append(adyacente(i, j) ? "  1 " : "  0 ");
            sb.append("\n");
        }

        System.out.println(sb);
        return sb.toString();
    }

    // =========================================================================
    //  METODOS DE MODIFICACION
    // =========================================================================

    public boolean insertarArista(int i, int j) {
        validar(i); validar(j);
        if (i == j) return false;
        if (adyacente(i, j)) return false;

        getEntrada(i).vecinos.insertarFin(j);
        setGradoEntrada(j, getGradoEntrada(j) + 1);
        setGradoSalida(i,  getGradoSalida(i)  + 1);

        if (tieneCiclos()) {
            getEntrada(i).vecinos.eliminarDato(j);
            setGradoEntrada(j, getGradoEntrada(j) - 1);
            setGradoSalida(i,  getGradoSalida(i)  - 1);
            return false;
        }

        numAristas++;
        return true;
    }

    public void eliminarAristas() {
        Nodo<EntradaAdyacencia> aux = listaAdyacencia.getInicio();
        while (aux != null) { aux.getInfo().vecinos.limpiar(); aux = aux.getSig(); }

        Nodo<Integer> ne = gradoEntrada.getInicio();
        Nodo<Integer> ns = gradoSalida.getInicio();
        while (ne != null) { ne.setInfo(0); ne = ne.getSig(); }
        while (ns != null) { ns.setInfo(0); ns = ns.getSig(); }
        numAristas = 0;
    }

    public int getNumVertices() { return numVertices; }
}
