import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Interfaz grafica estilo Windows clasico para el Grafo Dirigido Aciclico.
 * Replica el flujo del Main.java original: muestra el menu y los resultados
 * en un area de texto, exactamente igual que la consola.
 */
public class GrafoGUI extends JFrame {

    // ── Estado ────────────────────────────────────────────────────────────────
    private GrafoDirigidoAciclico grafo = null;

    // ── Componentes ----------------------------------------------------------
    private JTextArea  areaResultado;
    private JTextField tfInput;
    private JLabel     lblEstado;

    // ── Botones del menu -----------------------------------------------------
    private JButton[] botones;
    private static final String[] LABELS = {
        "1. Crear nuevo grafo",
        "2. Insertar arista",
        "3. Grado de entrada",
        "4. Grado de salida",
        "5. Cuantas aristas hay",
        "6. Estan conectados?",
        "7. Topological Sort",
        "8. Mostrar matriz",
        "9. Eliminar todas las aristas",
        "10. Grafo de demostracion",
        "0. Salir"
    };

    public GrafoGUI() {
        super("Grafo Dirigido Aciclico - Topological Sort");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(780, 560);
        setMinimumSize(new Dimension(680, 480));
        setLocationRelativeTo(null);
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
        catch (Exception ignored) {}

        buildUI();
        imprimirBienvenida();
        setVisible(true);
    }

    // =========================================================================
    //  CONSTRUCCION DE LA INTERFAZ
    // =========================================================================

    private void buildUI() {
        setLayout(new BorderLayout(4, 4));
        getContentPane().setBackground(new Color(236, 233, 216)); // fondo gris XP

        // -- Panel izquierdo: menu de botones ---------------------------------
        JPanel panelMenu = new JPanel(new GridBagLayout());
        panelMenu.setBackground(new Color(236, 233, 216));
        panelMenu.setBorder(new CompoundBorder(
            new TitledBorder(new EtchedBorder(), "Menu de opciones"),
            new EmptyBorder(4, 6, 4, 6)));
        panelMenu.setPreferredSize(new Dimension(210, 0));

        botones = new JButton[LABELS.length];
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1; gbc.insets = new Insets(2, 2, 2, 2);

        for (int i = 0; i < LABELS.length; i++) {
            botones[i] = new JButton(LABELS[i]);
            botones[i].setFont(new Font("Tahoma", Font.PLAIN, 12));
            botones[i].setHorizontalAlignment(SwingConstants.LEFT);
            botones[i].setFocusPainted(false);
            final int idx = i;
            botones[i].addActionListener(e -> manejarOpcion(idx));
            gbc.gridy = i;
            if (i == LABELS.length - 1) {
                gbc.insets = new Insets(10, 2, 2, 2); // separador antes de Salir
                botones[i].setForeground(new Color(180, 0, 0));
            }
            panelMenu.add(botones[i], gbc);
        }

        // Relleno para empujar botones hacia arriba
        gbc.gridy = LABELS.length; gbc.weighty = 1;
        panelMenu.add(Box.createVerticalGlue(), gbc);

        add(panelMenu, BorderLayout.WEST);

        // -- Panel derecho: area de salida + entrada --------------------------
        JPanel panelDerecho = new JPanel(new BorderLayout(4, 4));
        panelDerecho.setBackground(new Color(236, 233, 216));
        panelDerecho.setBorder(new EmptyBorder(6, 2, 6, 8));

        // Area de resultado (simula la consola)
        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setFont(new Font("Courier New", Font.PLAIN, 13));
        areaResultado.setBackground(Color.WHITE);
        areaResultado.setForeground(Color.BLACK);
        areaResultado.setMargin(new Insets(6, 8, 6, 8));

        JScrollPane scroll = new JScrollPane(areaResultado);
        scroll.setBorder(new TitledBorder(new EtchedBorder(), "Salida"));
        panelDerecho.add(scroll, BorderLayout.CENTER);

        // Panel de entrada inferior
        JPanel panelEntrada = new JPanel(new BorderLayout(4, 0));
        panelEntrada.setBackground(new Color(236, 233, 216));
        panelEntrada.setBorder(new TitledBorder(new EtchedBorder(), "Entrada"));

        tfInput = new JTextField();
        tfInput.setFont(new Font("Courier New", Font.PLAIN, 13));
        tfInput.addActionListener(e -> procesarEntrada());

        JButton btnOk = new JButton("OK");
        btnOk.setFont(new Font("Tahoma", Font.BOLD, 12));
        btnOk.setPreferredSize(new Dimension(60, 26));
        btnOk.addActionListener(e -> procesarEntrada());

        JButton btnLimpiar = new JButton("Limpiar");
        btnLimpiar.setFont(new Font("Tahoma", Font.PLAIN, 12));
        btnLimpiar.setPreferredSize(new Dimension(75, 26));
        btnLimpiar.addActionListener(e -> areaResultado.setText(""));

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        btnPanel.setBackground(new Color(236, 233, 216));
        btnPanel.add(btnLimpiar);
        btnPanel.add(btnOk);

        panelEntrada.add(new JLabel("  Valor: "), BorderLayout.WEST);
        panelEntrada.add(tfInput, BorderLayout.CENTER);
        panelEntrada.add(btnPanel, BorderLayout.EAST);

        panelDerecho.add(panelEntrada, BorderLayout.SOUTH);
        add(panelDerecho, BorderLayout.CENTER);

        // -- Barra de estado --------------------------------------------------
        lblEstado = new JLabel(" Sin grafo cargado");
        lblEstado.setFont(new Font("Tahoma", Font.PLAIN, 11));
        lblEstado.setBorder(new CompoundBorder(
            new MatteBorder(1, 0, 0, 0, Color.GRAY),
            new EmptyBorder(3, 6, 3, 6)));
        lblEstado.setBackground(new Color(236, 233, 216));
        lblEstado.setOpaque(true);
        add(lblEstado, BorderLayout.SOUTH);
    }

    // =========================================================================
    //  ESTADO DE ESPERA DE ENTRADA
    // =========================================================================

    // Guardamos que operacion esta esperando entrada y en que paso
    private int  operacionActual = -1;
    private int  pasoActual      = 0;
    private int  tmpN, tmpI, tmpJ;
    private String[] tmpNombres;

    private void manejarOpcion(int idx) {
        // idx mapea a opciones 1,2,3,...,10,0
        int[] opciones = {1,2,3,4,5,6,7,8,9,10,0};
        int op = opciones[idx];
        ejecutarOpcion(op);
    }

    private void ejecutarOpcion(int op) {
        operacionActual = op;
        pasoActual = 0;
        tmpN = 0; tmpI = -1; tmpJ = -1;
        tmpNombres = null;

        switch (op) {
            case 1 -> { print(""); print("[ Opcion 1: Crear nuevo grafo ]");
                        print("Cuantos vertices tendra el grafo?"); habilitarEntrada(); }
            case 2 -> { if (!hayGrafo()) return;
                        print(""); print("[ Opcion 2: Insertar arista ]");
                        mostrarVertices(); print("Indice vertice ORIGEN (i):"); habilitarEntrada(); }
            case 3 -> { if (!hayGrafo()) return; accionGradoEntrada(); }
            case 4 -> { if (!hayGrafo()) return; accionGradoSalida(); }
            case 5 -> { if (!hayGrafo()) return;
                        print(""); print("[ Opcion 5: Cuantas aristas hay ]");
                        print("Total de aristas: " + grafo.cuantasAristasHay()); }
            case 6 -> { if (!hayGrafo()) return;
                        print(""); print("[ Opcion 6: Estan conectados? ]");
                        mostrarVertices(); print("Indice origen i:"); habilitarEntrada(); }
            case 7 -> { if (!hayGrafo()) return;
                        print(""); print("[ Opcion 7: Topological Sort ]");
                        print("=== ORDENAMIENTO TOPOLOGICO ===");
                        print(grafo.topologicalSort()); }
            case 8 -> { if (!hayGrafo()) return;
                        print(""); print("[ Opcion 8: Mostrar matriz ]");
                        accionMatriz(); }
            case 9 -> { if (!hayGrafo()) return;
                        print(""); print("[ Opcion 9: Eliminar todas las aristas ]");
                        print("Eliminar TODAS las aristas? (s/n):"); habilitarEntrada(); }
            case 10 -> { print(""); print("[ Opcion 10: Grafo de demostracion ]");
                         print("Selecciona grafo:");
                         print("  a) Letras PDF (B,E,A,D,C)");
                         print("  b) Numeros PDF (0,1,2,3)");
                         print("  c) 6 vertices");
                         print("Opcion (a/b/c):"); habilitarEntrada(); }
            case 0 -> { print(""); print("Hasta luego!"); System.exit(0); }
        }
    }

    private void procesarEntrada() {
        String val = tfInput.getText().trim();
        tfInput.setText("");
        if (val.isEmpty()) return;

        print("> " + val); // eco de lo que escribio el usuario

        switch (operacionActual) {

            // -- Crear grafo --------------------------------------------------
            case 1 -> {
                if (pasoActual == 0) {
                    try {
                        tmpN = Integer.parseInt(val);
                        if (tmpN <= 0) { print("Debe ser mayor a 0."); deshabilitarEntrada(); return; }
                        tmpNombres = new String[tmpN];
                        grafo = new GrafoDirigidoAciclico(tmpN);
                        print("Ingresa el nombre de cada vertice:");
                        print("  Nombre del vertice [0]:");
                        pasoActual = 1;
                    } catch (NumberFormatException e) { print("Numero invalido."); deshabilitarEntrada(); }
                } else {
                    int idx = pasoActual - 1;
                    String nombre = val.isEmpty() ? String.valueOf(idx) : val;
                    grafo.setNombre(idx, nombre);
                    pasoActual++;
                    if (pasoActual - 1 < tmpN) {
                        print("  Nombre del vertice [" + (pasoActual - 1) + "]:");
                    } else {
                        print("\nGrafo creado con " + tmpN + " vertices:");
                        for (int i = 0; i < tmpN; i++)
                            print("  [" + i + "] -> " + grafo.getNombre(i));
                        actualizarEstado();
                        deshabilitarEntrada();
                    }
                }
            }

            // -- Insertar arista ----------------------------------------------
            case 2 -> {
                if (pasoActual == 0) {
                    try { tmpI = Integer.parseInt(val); print("Indice vertice DESTINO (j):"); pasoActual = 1; }
                    catch (NumberFormatException e) { print("Numero invalido."); deshabilitarEntrada(); }
                } else {
                    try {
                        tmpJ = Integer.parseInt(val);
                        boolean ok = grafo.insertarArista(tmpI, tmpJ);
                        if (ok)
                            print("Arista " + grafo.getNombre(tmpI) + " -> " + grafo.getNombre(tmpJ) + " insertada.");
                        else
                            print("No se pudo insertar (duplicada, auto-arista o ciclo).");
                        actualizarEstado();
                    } catch (IllegalArgumentException e) { print("Error: " + e.getMessage()); }
                    deshabilitarEntrada();
                }
            }

            // -- Conectados ---------------------------------------------------
            case 6 -> {
                if (pasoActual == 0) {
                    try { tmpI = Integer.parseInt(val); print("Indice destino j:"); pasoActual = 1; }
                    catch (NumberFormatException e) { print("Numero invalido."); deshabilitarEntrada(); }
                } else {
                    try {
                        tmpJ = Integer.parseInt(val);
                        boolean r = grafo.conectados(tmpI, tmpJ);
                        print("Camino de [" + grafo.getNombre(tmpI) + "] a ["
                            + grafo.getNombre(tmpJ) + "]? " + (r ? "SI" : "NO"));
                    } catch (IllegalArgumentException e) { print("Error: " + e.getMessage()); }
                    deshabilitarEntrada();
                }
            }

            // -- Eliminar aristas ---------------------------------------------
            case 9 -> {
                if (val.equalsIgnoreCase("s")) {
                    grafo.eliminarAristas();
                    print("Aristas eliminadas. Total: " + grafo.cuantasAristasHay());
                    actualizarEstado();
                } else { print("Cancelado."); }
                deshabilitarEntrada();
            }

            // -- Demo ---------------------------------------------------------
            case 10 -> {
                switch (val.toLowerCase()) {
                    case "a" -> {
                        grafo = new GrafoDirigidoAciclico(5);
                        grafo.setNombre(0,"B"); grafo.setNombre(1,"E");
                        grafo.setNombre(2,"A"); grafo.setNombre(3,"D"); grafo.setNombre(4,"C");
                        grafo.insertarArista(0,1); grafo.insertarArista(0,4);
                        grafo.insertarArista(1,2); grafo.insertarArista(1,4);
                        grafo.insertarArista(2,3); grafo.insertarArista(4,3);
                        print("Grafo con letras cargado (B=0, E=1, A=2, D=3, C=4).");
                    }
                    case "b" -> {
                        grafo = new GrafoDirigidoAciclico(4);
                        grafo.insertarArista(0,2); grafo.insertarArista(0,1);
                        grafo.insertarArista(2,3); grafo.insertarArista(1,3);
                        print("Grafo con numeros cargado.");
                    }
                    default -> {
                        grafo = new GrafoDirigidoAciclico(6);
                        grafo.insertarArista(0,1); grafo.insertarArista(0,2);
                        grafo.insertarArista(1,3); grafo.insertarArista(2,3);
                        grafo.insertarArista(3,4); grafo.insertarArista(4,5);
                        print("Grafo de 6 vertices cargado.");
                    }
                }
                print("Usa las opciones del menu para probarlo.");
                actualizarEstado();
                deshabilitarEntrada();
            }
        }
    }

    // =========================================================================
    //  ACCIONES DIRECTAS (sin entrada de usuario)
    // =========================================================================

    private void accionGradoEntrada() {
        print(""); print("[ Opcion 3: Grado de entrada ]");
        print("=== GRADO DE ENTRADA ===");
        for (int i = 0; i < grafo.getNumVertices(); i++)
            print("  [" + grafo.getNombre(i) + "]: " + grafo.gradoDeEntrada(i));
    }

    private void accionGradoSalida() {
        print(""); print("[ Opcion 4: Grado de salida ]");
        print("=== GRADO DE SALIDA ===");
        for (int i = 0; i < grafo.getNumVertices(); i++)
            print("  [" + grafo.getNombre(i) + "]: " + grafo.gradoDeSalida(i));
    }

    private void accionMatriz() {
        int n = grafo.getNumVertices();
        StringBuilder sb = new StringBuilder("     ");
        for (int j = 0; j < n; j++)
            sb.append(String.format("%-4s", grafo.getNombre(j)));
        print(sb.toString());
        print("    " + "-".repeat(n * 4));
        for (int i = 0; i < n; i++) {
            StringBuilder row = new StringBuilder(String.format("%-4s", grafo.getNombre(i))).append("|");
            for (int j = 0; j < n; j++)
                row.append(grafo.adyacente(i, j) ? "  1 " : "  0 ");
            print(row.toString());
        }
    }

    // =========================================================================
    //  UTILIDADES
    // =========================================================================

    private void print(String s) {
        areaResultado.append(s + "\n");
        areaResultado.setCaretPosition(areaResultado.getDocument().getLength());
    }

    private void imprimirBienvenida() {
        print("╔══════════════════════════════════════════════╗");
        print("║   GRAFO DIRIGIDO ACICLICO - MENU PRINCIPAL   ║");
        print("╚══════════════════════════════════════════════╝");
        print("");
        print("Selecciona una opcion del menu de la izquierda.");
    }

    private boolean hayGrafo() {
        if (grafo == null) {
            print(""); print("ERROR: Primero crea un grafo (opcion 1 o 10)."); return false;
        }
        return true;
    }

    private void mostrarVertices() {
        print("Vertices disponibles:");
        for (int i = 0; i < grafo.getNumVertices(); i++)
            print("  [" + i + "] " + grafo.getNombre(i));
    }

    private void habilitarEntrada() {
        tfInput.setEnabled(true);
        tfInput.requestFocus();
        // Deshabilitar botones del menu mientras se espera entrada
        for (JButton b : botones) b.setEnabled(false);
    }

    private void deshabilitarEntrada() {
        tfInput.setEnabled(false);
        for (JButton b : botones) b.setEnabled(true);
        operacionActual = -1;
    }

    private void actualizarEstado() {
        if (grafo == null) { lblEstado.setText(" Sin grafo cargado"); return; }
        lblEstado.setText(" Vertices: " + grafo.getNumVertices()
            + "   |   Aristas: " + grafo.cuantasAristasHay());
    }

    // =========================================================================
    //  MAIN
    // =========================================================================

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GrafoGUI::new);
    }
}
