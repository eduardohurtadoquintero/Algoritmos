/**
 * Lista enlazada simple generica.
 * Usada como estructura base en todo el proyecto (adyacencias, grados, cola).
 */
public class ListaSimple<T> {
    private Nodo<T> inicio;

    public ListaSimple() { inicio = null; }

    public void insertarInicio(T dato) {
        Nodo<T> n = new Nodo<>(dato);
        n.setSig(inicio);
        inicio = n;
    }

    public void insertarFin(T dato) {
        Nodo<T> n = new Nodo<>(dato);
        if (inicio == null) { inicio = n; return; }
        Nodo<T> aux = inicio;
        while (aux.getSig() != null) aux = aux.getSig();
        aux.setSig(n);
    }

    public boolean eliminarDato(T dato) {
        if (inicio == null) return false;
        if (inicio.getInfo().equals(dato)) { inicio = inicio.getSig(); return true; }
        Nodo<T> aux = inicio;
        while (aux.getSig() != null) {
            if (aux.getSig().getInfo().equals(dato)) {
                aux.setSig(aux.getSig().getSig());
                return true;
            }
            aux = aux.getSig();
        }
        return false;
    }

    public T eliminarInicio() {
        if (inicio == null) return null;
        T dato = inicio.getInfo();
        inicio = inicio.getSig();
        return dato;
    }

    public boolean contiene(T dato) {
        Nodo<T> aux = inicio;
        while (aux != null) {
            if (aux.getInfo().equals(dato)) return true;
            aux = aux.getSig();
        }
        return false;
    }

    public Nodo<T> getInicio() { return inicio; }

    public int size() {
        int c = 0; Nodo<T> aux = inicio;
        while (aux != null) { c++; aux = aux.getSig(); }
        return c;
    }

    public boolean isEmpty() { return inicio == null; }
    public void limpiar()    { inicio = null; }

    public T get(int idx) {
        Nodo<T> aux = inicio; int i = 0;
        while (aux != null) {
            if (i == idx) return aux.getInfo();
            aux = aux.getSig(); i++;
        }
        return null;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        Nodo<T> aux = inicio;
        while (aux != null) {
            sb.append(aux.getInfo());
            if (aux.getSig() != null) sb.append(", ");
            aux = aux.getSig();
        }
        return sb.append("]").toString();
    }
}
